define(["dojo/_base/kernel"],
		function(kernel){
		kernel.deprecated('dojox.charting.BidiSupport is deprecated,', 'set "has: {\'dojo-bidi\': true }" in data-dojo-config to enable bidi support');
});
