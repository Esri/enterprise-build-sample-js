define(["../SimpleTheme", "./common"], function(SimpleTheme, themes){
	themes.GreySkies = new SimpleTheme();
	return themes.GreySkies;
});
