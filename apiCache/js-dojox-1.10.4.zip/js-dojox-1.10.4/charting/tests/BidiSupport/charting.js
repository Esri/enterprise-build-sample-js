define([
    	"dojox/charting/tests/Theme",
], 1);
