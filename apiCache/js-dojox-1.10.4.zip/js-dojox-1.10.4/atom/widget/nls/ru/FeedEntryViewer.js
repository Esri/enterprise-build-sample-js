define(
({
	displayOptions: "[показать опции]",
	title: "Название",
	authors: "Авторы",
	contributors: "Участники",
	id: "ИД",
	close: "[закрыть]",
	updated: "Обновлено",
	summary: "Сводка",
	content: "Информационное наполнение"
})
);
