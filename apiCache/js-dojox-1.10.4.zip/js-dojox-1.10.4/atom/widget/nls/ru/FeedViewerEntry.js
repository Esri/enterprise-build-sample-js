define(
({
	deleteButton: "[Удалить]"
})
);
