define(
({
	deleteButton: "[Eliminar]"
})
);
