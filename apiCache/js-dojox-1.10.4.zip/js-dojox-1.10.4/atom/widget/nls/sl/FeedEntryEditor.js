define(
({
	doNew: "[novo]",
	edit: "[urejanje]",
	save: "[shrani]",
	cancel: "[prekliči]"
})
);
