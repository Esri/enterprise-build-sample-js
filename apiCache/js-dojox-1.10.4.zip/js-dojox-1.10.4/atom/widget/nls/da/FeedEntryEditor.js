define(
({
	doNew: "[ny]",
	edit: "[redigér]",
	save: "[gem]",
	cancel: "[annullér]"
})
);
