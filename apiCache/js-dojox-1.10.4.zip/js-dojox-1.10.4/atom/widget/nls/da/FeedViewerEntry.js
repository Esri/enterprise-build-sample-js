define(
({
	deleteButton: "[Slet]"
})
);
