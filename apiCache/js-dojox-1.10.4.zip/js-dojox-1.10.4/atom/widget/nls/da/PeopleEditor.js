define(
({
	add: "Tilføj",
	addAuthor: "Tilføj forfatter",
	addContributor: "Tilføj bidragyder"
})
);
