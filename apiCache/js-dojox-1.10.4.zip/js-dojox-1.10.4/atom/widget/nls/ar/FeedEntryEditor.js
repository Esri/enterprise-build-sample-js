define(
({
	doNew: "[جديد]",
	edit: "[تحرير]",
	save: "[حفظ]",
	cancel: "[الغاء]"
})
);
