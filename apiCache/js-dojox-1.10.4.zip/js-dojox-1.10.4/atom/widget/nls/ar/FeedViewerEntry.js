define(
({
	deleteButton: "[حذف]"
})
);
