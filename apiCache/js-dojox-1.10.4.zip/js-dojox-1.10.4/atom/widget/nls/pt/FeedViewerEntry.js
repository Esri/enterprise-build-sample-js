define(
({
	deleteButton: "[Excluir]"
})
);
