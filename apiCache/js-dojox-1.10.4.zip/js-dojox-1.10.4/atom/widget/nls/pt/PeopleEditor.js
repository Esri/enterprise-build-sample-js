define(
({
	add: "Incluir",
	addAuthor: "Adicionar Autor",
	addContributor: "Adicionar Contribuidor"
})
);
