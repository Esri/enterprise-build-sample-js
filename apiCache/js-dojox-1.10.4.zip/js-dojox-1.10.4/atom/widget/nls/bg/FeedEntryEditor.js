define(
({
	doNew: "[нов]",
	edit: "[редактирай]",
	save: "[запази]",
	cancel: "[отмени]"
})
);
