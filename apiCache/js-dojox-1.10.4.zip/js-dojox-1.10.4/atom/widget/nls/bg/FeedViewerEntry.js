define(
({
	deleteButton: "[Изтрий]"
})
);
