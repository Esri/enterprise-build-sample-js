define(
({
	doNew: "[nou]",
	edit: "[editare]",
	save: "[salvare]",
	cancel: "[anulare]"
})
);
