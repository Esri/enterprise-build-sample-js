define(
({
	add: "Adăugare",
	addAuthor: "Adăugare autor",
	addContributor: "Adăugare contribuitor"
})
);
