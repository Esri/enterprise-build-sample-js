define(
({
	deleteButton: "[Ştergere]"
})
);
