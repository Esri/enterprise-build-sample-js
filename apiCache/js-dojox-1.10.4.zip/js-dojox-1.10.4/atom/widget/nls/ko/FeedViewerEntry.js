define(
({
	deleteButton: "[삭제]"
})
);
