define(
({
	doNew: "[새로 작성]",
	edit: "[편집]",
	save: "[저장]",
	cancel: "[취소]"
})
);
