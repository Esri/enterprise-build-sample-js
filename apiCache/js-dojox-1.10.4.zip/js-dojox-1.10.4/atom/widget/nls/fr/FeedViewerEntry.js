define(
({
	deleteButton: "[Supprimer]"
})
);
