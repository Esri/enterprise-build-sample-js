define(
({
	"deleteButton" : "[Sil]"
})
);
