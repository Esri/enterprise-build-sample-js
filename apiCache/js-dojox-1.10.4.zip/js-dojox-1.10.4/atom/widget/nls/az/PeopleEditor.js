define(
({
	"add" : "Əlavə Et",
	"addAuthor" : "Yazıçı Əlavə Et",
	"addContributor" : "Əməyi keçənlərə Əlavə Et"
})
);
