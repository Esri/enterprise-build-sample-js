define(
({
	deleteButton: "[Suprimeix]"
})
);
