define(
({
	deleteButton: "[Izbriši]"
})
);
