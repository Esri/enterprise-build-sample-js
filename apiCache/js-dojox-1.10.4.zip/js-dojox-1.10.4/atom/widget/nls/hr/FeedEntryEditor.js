define(
({
	doNew: "[novo]",
	edit: "[uredi]",
	save: "[spremi]",
	cancel: "[opoziv]"
})
);
