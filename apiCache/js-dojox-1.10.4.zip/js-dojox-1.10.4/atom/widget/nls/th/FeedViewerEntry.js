define(
({
	deleteButton: "[ลบ]"
})
);
