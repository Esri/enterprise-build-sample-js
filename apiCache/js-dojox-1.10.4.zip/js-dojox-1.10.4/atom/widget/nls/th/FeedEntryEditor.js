define(
({
	doNew: "[สร้างใหม่]",
	edit: "[แก้ไข]",
	save: "[บันทึก]",
	cancel: "[ยกเลิก]"
})
);
