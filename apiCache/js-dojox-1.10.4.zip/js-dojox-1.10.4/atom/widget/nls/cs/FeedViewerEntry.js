define(
({
	deleteButton: "[Odstranit]"
})
);
