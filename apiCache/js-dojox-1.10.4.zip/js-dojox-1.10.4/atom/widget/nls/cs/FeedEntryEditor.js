define(
({
	doNew: "[nové]",
	edit: "[upravit]",
	save: "[uložit]",
	cancel: "[storno]"
})
);
