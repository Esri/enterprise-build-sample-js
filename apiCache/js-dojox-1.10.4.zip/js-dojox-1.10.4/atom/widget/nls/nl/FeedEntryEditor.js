define(
({
	doNew: "[nieuw]",
	edit: "[bewerken]",
	save: "[opslaan]",
	cancel: "[annuleren]"
})
);
