define(
({
	deleteButton: "[Wissen]"
})
);
