define(
({
	displayOptions: "[voľby zobrazenia]",
	title: "Nadpis",
	authors: "Autori",
	contributors: "Prispievatelia",
	id: "ID",
	close: "[zatvoriť]",
	updated: "Aktualizované",
	summary: "Zhrnutie",
	content: "Obsah"
})
);
