define(
({
	doNew: "[nový]",
	edit: "[upraviť]",
	save: "[uložiť]",
	cancel: "[zrušiť]"
})
);
