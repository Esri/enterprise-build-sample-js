define(
({
	add: "Pridať",
	addAuthor: "Pridať autora",
	addContributor: "Pridať prispievateľa"
})
);
