define(
({
	deleteButton: "[Odstrániť]"
})
);
