define(
({
	deleteButton: "[Διαγραφή]"
})
);
