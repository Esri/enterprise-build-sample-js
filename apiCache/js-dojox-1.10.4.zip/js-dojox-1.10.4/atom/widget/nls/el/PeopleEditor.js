define(
({
	add: "Προσθήκη",
	addAuthor: "Προσθήκη συντάκτη",
	addContributor: "Προσθήκη συνεισφέροντα"
})
);
