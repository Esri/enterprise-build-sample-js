define(
({
	doNew: "[жаңа]",
	edit: "[өңдеу]",
	save: "[сақтау]",
	cancel: "[болдырмау]"
})
);
