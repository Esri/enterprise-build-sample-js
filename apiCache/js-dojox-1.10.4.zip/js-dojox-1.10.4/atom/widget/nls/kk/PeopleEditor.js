define(
({
	add: "Қосу",
	addAuthor: "Авторды қосу",
	addContributor: "Салымшыны қосу"
})
);
