define(
({
	deleteButton: "[Жою]"
})
);
