define(
({
	displayOptions: "[көрсету параметрлері]",
	title: "Тақырып",
	authors: "Авторлар",
	contributors: "Салымшылар",
	id: "Жалпылауыш",
	close: "[жабу]",
	updated: "Жаңартылған",
	summary: "Жиынтық",
	content: "Мазмұн"
})
);
