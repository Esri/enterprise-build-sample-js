define(
({
	doNew: "[nuovo]",
	edit: "[modifica]",
	save: "[salva]",
	cancel: "[annulla]"
})
);
