define(
({
	displayOptions: "[visualizza opzioni]",
	title: "Titolo",
	authors: "Autori",
	contributors: "Contributor",
	id: "ID",
	close: "[chiudi]",
	updated: "Aggiornato",
	summary: "Riepilogo",
	content: "Contenuto"
})
);
