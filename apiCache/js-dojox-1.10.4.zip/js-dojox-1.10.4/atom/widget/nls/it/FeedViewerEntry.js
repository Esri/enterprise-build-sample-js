define(
({
	deleteButton: "[Elimina]"
})
);
