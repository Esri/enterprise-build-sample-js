define(
({
	add: "Aggiungi",
	addAuthor: "Aggiungi autore",
	addContributor: "Aggiungi contributor"
})
);
