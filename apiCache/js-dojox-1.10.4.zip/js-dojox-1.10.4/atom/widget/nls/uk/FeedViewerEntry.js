define(
({
	deleteButton: "[Видалити]"
})
);
