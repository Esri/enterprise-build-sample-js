define(
({
	add: "Додати",
	addAuthor: "Додати автора",
	addContributor: "Додати учасника"
})
);
