define(
({
	deleteButton: "[Sil]"
})
);
