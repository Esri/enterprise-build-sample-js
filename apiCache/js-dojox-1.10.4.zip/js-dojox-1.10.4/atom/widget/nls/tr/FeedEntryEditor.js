define(
({
	doNew: "[yeni]",
	edit: "[düzenle]",
	save: "[kaydet]",
	cancel: "[iptal]"
})
);
