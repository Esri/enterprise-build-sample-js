define(
({
	add: "Lägg till",
	addAuthor: "Lägg till författare",
	addContributor: "Lägg till medverkande"
})
);
