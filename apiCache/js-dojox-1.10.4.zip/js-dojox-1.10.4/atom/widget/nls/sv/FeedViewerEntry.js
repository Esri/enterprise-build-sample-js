define(
({
	deleteButton: "[Ta bort]"
})
);
