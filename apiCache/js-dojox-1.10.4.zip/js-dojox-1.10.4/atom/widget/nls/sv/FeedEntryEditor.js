define(
({
	doNew: "[nytt]",
	edit: "[redigera]",
	save: "[spara]",
	cancel: "[avbryt]"
})
);
