define(
({
	deleteButton: "[削除]"
})
);
