define(
({
	add: "追加",
	addAuthor: "作成者の追加",
	addContributor: "貢献者の追加"
})
);
