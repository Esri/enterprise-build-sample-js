define(
({
	doNew: "[新規]",
	edit: "[編集]",
	save: "[保存]",
	cancel: "[キャンセル]"
})
);
