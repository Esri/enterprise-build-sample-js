define(
({
	add: "新增",
	addAuthor: "新增作者",
	addContributor: "新增貢獻者"
})
);
