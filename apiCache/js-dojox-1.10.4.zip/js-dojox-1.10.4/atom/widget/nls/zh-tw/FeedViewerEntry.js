define(
({
	deleteButton: "[刪除]"
})
);
