define(
({
	doNew: "[új]",
	edit: "[szerkesztés]",
	save: "[mentés]",
	cancel: "[mégse]"
})
);
