define(
({
	deleteButton: "[Törlés]"
})
);
