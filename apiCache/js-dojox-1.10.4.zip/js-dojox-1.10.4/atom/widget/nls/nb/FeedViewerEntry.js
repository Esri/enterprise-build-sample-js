define(
({
	deleteButton: "[Slett]"
})
);
