define(
({
	doNew: "[ny(tt)]",
	edit: "[rediger]",
	save: "[lagre]",
	cancel: "[avbryt]"
})
);
