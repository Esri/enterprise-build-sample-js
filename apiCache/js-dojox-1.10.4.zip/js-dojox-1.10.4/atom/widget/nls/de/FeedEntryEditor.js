define(
({
	doNew: "[Neu]",
	edit: "[Bearbeiten]",
	save: "[Speichern]",
	cancel: "[Abbrechen]"
})
);
