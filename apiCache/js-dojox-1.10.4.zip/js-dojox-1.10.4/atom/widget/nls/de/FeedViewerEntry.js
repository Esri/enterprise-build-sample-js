define(
({
	deleteButton: "[Löschen]"
})
);
