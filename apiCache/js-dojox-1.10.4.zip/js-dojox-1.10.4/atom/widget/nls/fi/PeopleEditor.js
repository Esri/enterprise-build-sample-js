define(
({
	add: "Lisää",
	addAuthor: "Lisää tekijä",
	addContributor: "Lisää lisääjä"
})
);
