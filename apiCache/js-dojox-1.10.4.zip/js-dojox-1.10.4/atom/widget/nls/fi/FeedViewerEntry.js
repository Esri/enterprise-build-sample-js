define(
({
	deleteButton: "[Poista]"
})
);
