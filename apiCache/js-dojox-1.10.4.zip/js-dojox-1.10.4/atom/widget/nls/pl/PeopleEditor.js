define(
({
	add: "Dodaj",
	addAuthor: "Dodaj autora",
	addContributor: "Dodaj kontrybutora"
})
);
