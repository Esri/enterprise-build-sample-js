define(
({
	deleteButton: "[Usuń]"
})
);
