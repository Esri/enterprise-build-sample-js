define(
({
	doNew: "[nowy]",
	edit: "[edytuj]",
	save: "[zapisz]",
	cancel: "[anuluj]"
})
);
