define(
({
	doNew: "[חדש]",
	edit: "[עריכה]",
	save: "[שמירה]",
	cancel: "[ביטול]"
})
);
