define(
({
	add: "הוספה",
	addAuthor: "הוספת מחבר",
	addContributor: "הוספת תורם"
})
);
