define(
({
	deleteButton: "[מחיקה]"
})
);
