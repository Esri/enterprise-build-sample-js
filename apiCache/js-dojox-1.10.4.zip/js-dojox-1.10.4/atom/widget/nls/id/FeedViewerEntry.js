define(
({
	deleteButton: "[Hapus]"
})
);

