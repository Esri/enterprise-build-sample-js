define(
({
	doNew: "[baru]",
	edit: "[edit]",
	save: "[simpan]",
	cancel: "[batal]"
})
);

