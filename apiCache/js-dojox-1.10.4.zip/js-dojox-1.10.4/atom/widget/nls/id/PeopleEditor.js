define(
({
	add: "Tambahkan",
	addAuthor: "Tambahkan Penulis",
	addContributor: "Tambahkan Kontributor"
})
);

