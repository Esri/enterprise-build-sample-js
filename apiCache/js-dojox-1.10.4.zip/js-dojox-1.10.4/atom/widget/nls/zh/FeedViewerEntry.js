define(
({
	deleteButton: "[删除]"
})
);
