define(
({
	displayOptions: "[显示选项]",
	title: "标题",
	authors: "创建者",
	contributors: "添加者",
	id: "标识",
	close: "[关闭]",
	updated: "已更新",
	summary: "概要",
	content: "内容"
})
);
