//>>built
define(["dojo/_base/declare","dojo/has","./kernel","./IdentityManagerBase"],function(a,c,d,b){return a(b.Credential,{})});