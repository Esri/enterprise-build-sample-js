Release notes are now maintained on the GitHub repository's
[releases page](https://github.com/SitePen/dgrid/releases).