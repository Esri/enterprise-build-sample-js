define(
//begin v1.x content
{
	"dateFormatItem-yMEd": "E, y-MM-dd",
	"dateFormatItem-yMd": "y-MM-dd",
	"dateFormat-short": "y-MM-dd",
	"dateFormatItem-MEd": "E, MM-dd",
	"dateFormatItem-yM": "y-MM",
	"dateFormatItem-Md": "MM-dd"
}
//end v1.x content
);