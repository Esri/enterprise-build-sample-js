define(
//begin v1.x content
{
	"dateFormatItem-yyyyMEd": "E, GGGGG y-MM-dd",
	"dateFormat-short": "GGGGG y-MM-dd",
	"dateFormatItem-yyyyM": "GGGGG y-MM",
	"dateFormatItem-MEd": "E, MM-dd",
	"dateFormatItem-Md": "MM-dd",
	"dateFormatItem-yyyyMd": "GGGGG y-MM-dd"
}
//end v1.x content
);