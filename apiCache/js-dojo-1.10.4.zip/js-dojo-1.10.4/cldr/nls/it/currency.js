define(
//begin v1.x content
{
	"HKD_displayName": "Dollaro di Hong Kong",
	"CHF_displayName": "Franco Svizzero",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Dollaro Canadese",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Renmimbi Cinese",
	"USD_symbol": "US$",
	"AUD_displayName": "Dollaro Australiano",
	"JPY_displayName": "Yen Giapponese",
	"CAD_symbol": "CA$",
	"USD_displayName": "Dollaro Statunitense",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Sterlina Inglese",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);