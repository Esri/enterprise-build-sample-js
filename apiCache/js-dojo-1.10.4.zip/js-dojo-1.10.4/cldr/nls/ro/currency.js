define(
//begin v1.x content
{
	"HKD_displayName": "dolar din Hong Kong",
	"CHF_displayName": "franc elvețian",
	"JPY_symbol": "JPY",
	"CAD_displayName": "dolar canadian",
	"HKD_symbol": "HKD",
	"CNY_displayName": "yuan renminbi chinezesc",
	"USD_symbol": "USD",
	"AUD_displayName": "dolar australian",
	"JPY_displayName": "yen japonez",
	"CAD_symbol": "CAD",
	"USD_displayName": "dolar american",
	"CNY_symbol": "CNY",
	"GBP_displayName": "liră sterlină",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "euro"
}
//end v1.x content
);