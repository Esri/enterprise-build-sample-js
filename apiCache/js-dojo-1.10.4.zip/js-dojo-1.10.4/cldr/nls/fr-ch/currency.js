define(
//begin v1.x content
{
	"CHF_symbol": "CHF"
}
//end v1.x content
);