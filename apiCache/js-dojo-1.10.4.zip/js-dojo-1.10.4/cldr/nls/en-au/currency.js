define(
//begin v1.x content
{
	"EUR_displayName": "Euro",
	"AUD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);