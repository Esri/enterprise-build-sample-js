define(
({
	buttonOk: "OK",
	buttonCancel: "Opoziv",
	buttonSave: "Spremi",
	itemClose: "Zatvori"
})
);
