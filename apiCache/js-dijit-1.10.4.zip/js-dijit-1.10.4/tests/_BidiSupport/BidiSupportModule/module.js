define([
	"./BidiSupportTest"
], 1);