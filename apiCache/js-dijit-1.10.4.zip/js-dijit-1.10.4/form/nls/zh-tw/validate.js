define(
({
	invalidMessage: "輸入的值無效。",
	missingMessage: "必須提供此值。",
	rangeMessage: "此值超出範圍。"
})
);
